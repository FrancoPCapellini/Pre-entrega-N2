from setuptools import setup

setup(
    name="TuModeloDeClientes+Peña",
    version="1.0",
    author="Franco Peña",
    description="se esta haciendo la version 1.0 de la pre-entrega",
    author_email="francocapellinipena@gmail.com",
    packages=["paquete1"],
    )

#python setup.py sdist